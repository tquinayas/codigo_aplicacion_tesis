export interface Photo {
    filePath: string;
    webviewPath: string;
    base64?: string;
  
  }